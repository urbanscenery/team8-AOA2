$(document).ready(function() {
    $('input#input_text, textarea#textarea2').characterCounter();
});